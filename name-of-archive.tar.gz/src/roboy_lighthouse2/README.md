the folder nanopb was copied from the original built source
and everythin inside the generator folder was granted +x permissions
